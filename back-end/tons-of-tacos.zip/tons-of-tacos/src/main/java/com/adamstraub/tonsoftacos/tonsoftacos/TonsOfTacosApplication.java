package com.adamstraub.tonsoftacos.tonsoftacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TonsOfTacosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TonsOfTacosApplication.class, args);
	}

}
